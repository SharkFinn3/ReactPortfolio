import React from "react";

import styles from "./Hero.module.css";
import { getImageUrl } from "../../utils";

export const Hero = () => {

  var TxtType = function(el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 10) || 2000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
};

TxtType.prototype.tick = function() {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];

    if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
    } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
    }

    this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

    var that = this;
    var delta = 200 - Math.random() * 100;

    if (this.isDeleting) { delta /= 2; }

    if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
    }

    setTimeout(function() {
    that.tick();
    }, delta);
};

window.onload = function() {
    var elements = document.getElementsByClassName('typewrite');
    for (var i=0; i<elements.length; i++) {
        var toRotate = elements[i].getAttribute('data-type');
        var period = elements[i].getAttribute('data-period');
        if (toRotate) {
          new TxtType(elements[i], JSON.parse(toRotate), period);
        }
    }
    // INJECT CSS
    var css = document.createElement("style");
    css.type = "text/css";
    css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
    document.body.appendChild(css);
};
  return (
    <section className={styles.container}>
      <div className={styles.content}>
        <h1 className={styles.title}>Hi, I'm Shafin Alam</h1>
        <h1 className={`${styles.typewrite} typewrite`} data-period="2000" data-type='[ "Software Engineer", "Full Stack Developer", "Open Source Contributor", "Student", "Mentor" ]'>
          {/* <a href="" class="typewrite" data-period="2000" data-type='[ "Software Engineer", "Full Stack Developer", "Open Source Contributer", "Student", "Mentor" ]'> */}
            <span class="wrap"></span>
            {/* </a> */}
        </h1>
        <p className={styles.description}>
          <br />
          I am a senior pursuing my Bachelors in Computer Science & Engineering at The Ohio State University.
               Additionally, I am employed as a SWE Teaching Assistant. 
               From devising secure communication strategies for Special Operation Forces to creating engaging applications for real-time data interaction, I thrive on delivering impactful solutions.
               I'm currently exploring Software Engineer & Data Analyst roles and would love to connect on Linkedin.
               <br />
               <br />
               <p className={styles.quote}>
               "Our greatest weakness lies in giving up. The most certain way to succeed is always to try just one more time." – Thomas A. Edison
               </p>
               {/* Apart from coding, here are some other activities that I love to do! */}
               {/* <li>
                   Video Games
               </li>
               <li>
                   Travelling
               </li>
               <li>
                   Mentoring
               </li>
               <li>
                   Volunteering
               </li>
               I'm currently exploring Software Engineer & Data Analyst roles and would love to connect on Linkedin. */}
           </p>


        {/* <a href="mailto:myemail@email.com" className={styles.contactBtn}>
          Contact Me
        </a> */}
      </div>
      <img
        src={getImageUrl("hero/heroImage.png")}
        alt="Hero image of me"
        className={styles.heroImg}
      />
      <div className={styles.topBlur} />
      <div className={styles.bottomBlur} />
    </section>
  );
};
