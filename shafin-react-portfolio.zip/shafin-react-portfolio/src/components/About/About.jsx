import React from "react";

import styles from "./About.module.css";
import { getImageUrl } from "../../utils";

export const About = () => {
  return (
    <section className={styles.container} id="about">
      <h2 className={styles.title}>About Me</h2>
      <div className={styles.content}>
        <img
          src={getImageUrl("about/aboutImage.png")}
          alt="Me sitting with a laptop"
          className={styles.aboutImage}
        />
        <ul className={styles.aboutItems}>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="Cursor icon" />
            <div className={styles.aboutItemText}>
              <h3>Full Stack Developer</h3>
              <p>
                I'm a full-stack developer skilled in creating robust and scalable web applications, from front-end user interfaces to back-end databases. Recently, I've started exploring React.js to expand my web development toolkit.
              </p>


            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/serverIcon.png")} alt="Server icon" />
            <div className={styles.aboutItemText}>
              <h3>Software Engineer</h3>
              <p>
                I'm a software engineer specializing in crafting efficient and scalable solutions across multiple programming languages, frameworks, and platforms.
              </p>


            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="UI icon" />
            <div className={styles.aboutItemText}>
              <h3>Open Source Contributer</h3>
              <p>
                I'm an open-source contributor dedicated to enhancing and innovating within collaborative software projects across the globe.
                </p>

            </div>
          </li>
        </ul>
      </div>
    </section>
  );
};
