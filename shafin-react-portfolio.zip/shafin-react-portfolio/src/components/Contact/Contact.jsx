import React from "react";

import styles from "./Contact.module.css";
import { getImageUrl } from "../../utils";

export const Contact = () => {
  return (
    <footer id="contact" className={styles.container}>
      <div className={styles.wrapperDiv}> {/* New wrapper div */}
        <div className={styles.text}>
          {/* <h2>Contact Me</h2> */}
          <p>Feel free to <span className={styles.highlight}>connect</span> with me!</p>
        </div>
        <ul className={styles.links}>
        <li className={styles.link}>
          {/* <img src={getImageUrl("contact/emailIcon.png")} alt="Email icon" /> */}
          <a href="mailto:alamshafin3@mail.com">
          <ion-icon name="mail-outline"></ion-icon>
          </a>
        </li>
        <li className={styles.link}>
          {/* <img
            src={getImageUrl("contact/linkedinIcon.png")}
            alt="LinkedIn icon"
          /> */}
          <a href="https://www.linkedin.com/in/shafinalam/" target="_blank">
          <ion-icon name="logo-linkedin"></ion-icon>
          </a>
        </li>
        <li className={styles.link}>
          {/* <img src={getImageUrl("contact/githubIcon.png")} alt="Github icon" /> */}
          <a href="https://github.com/SharkFinn3" target="_blank">
          <ion-icon name="logo-github"></ion-icon>
          </a>
        </li>
      </ul>
      </div> {/* End of new wrapper div */}

      <div className={styles.footerBottom}>
        <p>Designed & Developed by Shafin Alam.</p>
        <p>Copyright © SA |  All Rights Reserved.</p>
      </div>

    </footer>
  );
};
